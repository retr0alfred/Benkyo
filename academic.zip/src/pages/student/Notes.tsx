import { useState } from "react";
import DashboardLayout from "@/components/layouts/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Search, Calendar, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const Notes = () => {
  const [searchTerm, setSearchTerm] = useState("");

  // Updated mock data based on provided recentNotes and upcomingAssignments
  const notes = [
    {
      id: "1",
      title: "Operating Systems: Process Scheduling",
      date: "2025-04-09",
      content: "Explored CPU scheduling algorithms like Round-Robin and Priority Scheduling. Discussed how these algorithms optimize process execution in operating systems.",
      course: "SCSB2401",
      blackboardImages: [
        { id: "img1", url: "/placeholder.svg", timestamp: "00:10:00", recordingId: "rec1", noteId: "1" }
      ]
    },
    {
      id: "2",
      title: "Databases: Relational Models",
      date: "2025-04-08",
      content: "Discussed normalization techniques and ER diagrams for database design. Covered the importance of reducing data redundancy and improving query efficiency.",
      course: "S11BLH41",
      blackboardImages: []
    },
    {
      id: "3",
      title: "Machine Learning: K-Means Clustering",
      date: "2025-04-07",
      content: "Introduction to unsupervised learning and the K-Means algorithm for clustering. Learned about initializing centroids and iteratively optimizing cluster assignments.",
      course: "SCSB4009",
      blackboardImages: [
        { id: "img2", url: "/placeholder.svg", timestamp: "00:05:30", recordingId: "rec3", noteId: "3" },
        { id: "img3", url: "/placeholder.svg", timestamp: "00:25:00", recordingId: "rec3", noteId: "3" }
      ]
    },
  ];

  const filteredNotes = notes.filter(
    note => note.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
            note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
            note.course.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout title="Class Notes">
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search notes by title, content or course..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 input-pastel"
            />
          </div>
          <Button className="bg-pastel-blue hover:bg-pastel-blue/80 text-primary-foreground">
            <Calendar className="mr-2 h-4 w-4" />
            Filter by Date
          </Button>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Notes</TabsTrigger>
            <TabsTrigger value="os">Operating Systems</TabsTrigger>
            <TabsTrigger value="dbms">Database Management Systems</TabsTrigger>
            <TabsTrigger value="ml">Machine Learning</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-4">
            {filteredNotes.length > 0 ? (
              filteredNotes.map(note => (
                <Card key={note.id} className="card-pastel border-pastel-blue">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <div>
                        <CardTitle className="text-xl font-medium">{note.title}</CardTitle>
                        <CardDescription>{new Date(note.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</CardDescription>
                      </div>
                      <Badge className="bg-pastel-blue text-primary-foreground">{note.course}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{note.content}</p>
                    
                    {note.blackboardImages.length > 0 && (
                      <div className="mt-4">
                        <p className="text-sm font-medium mb-2">Blackboard Images:</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                          {note.blackboardImages.map(image => (
                            <div key={image.id} className="relative border rounded overflow-hidden">
                              <img src={image.url} alt="Blackboard" className="w-full h-auto" />
                              <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground text-xs px-1 py-0.5">
                                {image.timestamp}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-4 flex justify-end space-x-2">
                      <Button variant="outline" className="text-xs">
                        <FileText className="h-3 w-3 mr-1" />
                        Generate Flashcards
                      </Button>
                      <Button size="sm" className="bg-pastel-blue hover:bg-pastel-blue/80 text-primary-foreground text-xs">
                        <BookOpen className="h-3 w-3 mr-1" />
                        Open Full Notes
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-10">
                <p className="text-muted-foreground">No notes found matching your search criteria.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="os" className="space-y-4">
            {filteredNotes.filter(note => note.course.includes('SCSB2401')).length > 0 ? (
              filteredNotes
                .filter(note => note.course.includes('SCSB2401'))
                .map(note => (
                  <Card key={note.id} className="card-pastel border-pastel-blue">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <div>
                          <CardTitle className="text-xl font-medium">{note.title}</CardTitle>
                          <CardDescription>{new Date(note.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</CardDescription>
                        </div>
                        <Badge className="bg-pastel-blue text-primary-foreground">{note.course}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{note.content}</p>
                      
                      {note.blackboardImages.length > 0 && (
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Blackboard Images:</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                            {note.blackboardImages.map(image => (
                              <div key={image.id} className="relative border rounded overflow-hidden">
                                <img src={image.url} alt="Blackboard" className="w-full h-auto" />
                                <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground text-xs px-1 py-0.5">
                                  {image.timestamp}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4 flex justify-end space-x-2">
                        <Button variant="outline" className="text-xs">
                          <FileText className="h-3 w-3 mr-1" />
                          Generate Flashcards
                        </Button>
                        <Button size="sm" className="bg-pastel-blue hover:bg-pastel-blue/80 text-primary-foreground text-xs">
                          <BookOpen className="h-3 w-3 mr-1" />
                          Open Full Notes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="text-center py-10">
                <p className="text-muted-foreground">No Operating Systems notes found.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="dbms" className="space-y-4">
            {filteredNotes.filter(note => note.course.includes('S11BLH41')).length > 0 ? (
              filteredNotes
                .filter(note => note.course.includes('S11BLH41'))
                .map(note => (
                  <Card key={note.id} className="card-pastel border-pastel-blue">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <div>
                          <CardTitle className="text-xl font-medium">{note.title}</CardTitle>
                          <CardDescription>{new Date(note.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</CardDescription>
                        </div>
                        <Badge className="bg-pastel-blue text-primary-foreground">{note.course}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{note.content}</p>
                      
                      {note.blackboardImages.length > 0 && (
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Blackboard Images:</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                            {note.blackboardImages.map(image => (
                              <div key={image.id} className="relative border rounded overflow-hidden">
                                <img src={image.url} alt="Blackboard" className="w-full h-auto" />
                                <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground text-xs px-1 py-0.5">
                                  {image.timestamp}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4 flex justify-end space-x-2">
                        <Button variant="outline" className="text-xs">
                          <FileText className="h-3 w-3 mr-1" />
                          Generate Flashcards
                        </Button>
                        <Button size="sm" className="bg-pastel-blue hover:bg-pastel-blue/80 text-primary-foreground text-xs">
                          <BookOpen className="h-3 w-3 mr-1" />
                          Open Full Notes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="text-center py-10">
                <p className="text-muted-foreground">No Database Management Systems notes found.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="ml" className="space-y-4">
            {filteredNotes.filter(note => note.course.includes('SCSB4009')).length > 0 ? (
              filteredNotes
                .filter(note => note.course.includes('SCSB4009'))
                .map(note => (
                  <Card key={note.id} className="card-pastel border-pastel-blue">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <div>
                          <CardTitle className="text-xl font-medium">{note.title}</CardTitle>
                          <CardDescription>{new Date(note.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</CardDescription>
                        </div>
                        <Badge className="bg-pastel-blue text-primary-foreground">{note.course}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{note.content}</p>
                      
                      {note.blackboardImages.length > 0 && (
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Blackboard Images:</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                            {note.blackboardImages.map(image => (
                              <div key={image.id} className="relative border rounded overflow-hidden">
                                <img src={image.url} alt="Blackboard" className="w-full h-auto" />
                                <div className="absolute bottom-0 right-0 bg-primary text-primary-foreground text-xs px-1 py-0.5">
                                  {image.timestamp}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4 flex justify-end space-x-2">
                        <Button variant="outline" className="text-xs">
                          <FileText className="h-3 w-3 mr-1" />
                          Generate Flashcards
                        </Button>
                        <Button size="sm" className="bg-pastel-blue hover:bg-pastel-blue/80 text-primary-foreground text-xs">
                          <BookOpen className="h-3 w-3 mr-1" />
                          Open Full Notes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="text-center py-10">
                <p className="text-muted-foreground">No Machine Learning notes found.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default Notes;