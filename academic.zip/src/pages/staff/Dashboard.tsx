import React, { useState } from "react";
import DashboardLayout from "@/components/layouts/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Mic, MicOff, Camera, Clock, FileText, BookOpen, Calendar } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

// Updated mock data for recent classes
const recentClasses = [
  {
    id: 1,
    title: "Operating Systems - Process Scheduling",
    date: "2025-04-09",
    duration: "1h 15m",
    status: "Processed",
    notes: true,
    flashcards: true,
    quizzes: true,
  },
  {
    id: 2,
    title: "DBMS - Normalization Techniques",
    date: "2025-04-08",
    duration: "55m",
    status: "Processed",
    notes: true,
    flashcards: true,
    quizzes: false,
  },
  {
    id: 3,
    title: "Machine Learning - K-Means Clustering",
    date: "2025-04-07",
    duration: "1h 30m",
    status: "Processing",
    notes: true,
    flashcards: false,
    quizzes: false,
  },
  {
    id: 4,
    title: "Data Structures - Binary Search Trees",
    date: "2025-04-06",
    duration: "1h 10m",
    status: "Processed",
    notes: true,
    flashcards: true,
    quizzes: true,
  },
];

const StaffDashboard = () => {
  const [recording, setRecording] = useState(false);
  const [lectureName, setLectureName] = useState("");
  const [recordingTime, setRecordingTime] = useState(0);
  const [captureBlackboard, setCaptureBlackboard] = useState(false);

  // Simulated recording timer
  React.useEffect(() => {
    let interval: number | undefined;

    if (recording) {
      interval = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } else if (!recording && recordingTime !== 0) {
      clearInterval(interval);
    }

    return () => clearInterval(interval);
  }, [recording, recordingTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStartRecording = () => {
    if (!lectureName.trim()) {
      toast.error("Please enter a lecture name before recording");
      return;
    }

    setRecording(true);
    toast.success(`Recording started: ${lectureName}`);
  };

  const handleStopRecording = () => {
    setRecording(false);
    toast.success(`Recording saved: ${lectureName} (${formatTime(recordingTime)})`);

    // Reset for next recording
    setLectureName("");
    setRecordingTime(0);
    setCaptureBlackboard(false);
  };

  return (
    <DashboardLayout title="Staff Dashboard">
      <div className="grid gap-6">
        {/* Recording Card */}
        <Card className={`border-2 ${recording ? "border-red-500 border-opacity-50 shadow-lg" : ""}`}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mic className="mr-2 h-5 w-5" />
              Class Recording
            </CardTitle>
            <CardDescription>
              Record lectures to automatically generate notes, flashcards, and quizzes
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label htmlFor="lectureName" className="text-sm font-medium">
                Lecture Name
              </label>
              <Input
                id="lectureName"
                value={lectureName}
                onChange={(e) => setLectureName(e.target.value)}
                placeholder="e.g., Operating Systems - April 10th"
                disabled={recording}
                className="mt-1"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="captureBlackboard"
                checked={captureBlackboard}
                onCheckedChange={setCaptureBlackboard}
                disabled={recording}
              />
              <label
                htmlFor="captureBlackboard"
                className="text-sm font-medium cursor-pointer flex items-center"
              >
                <Camera className="mr-2 h-4 w-4" />
                Automatically capture blackboard photos (every 10 minutes)
              </label>
            </div>

            {recording && (
              <div className="bg-red-50 p-4 rounded-md flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-red-500 mr-2 animate-pulse"></div>
                  <span className="font-medium">Recording: {formatTime(recordingTime)}</span>
                </div>
                <span className="text-sm text-muted-foreground">{lectureName}</span>
              </div>
            )}
          </CardContent>
          <CardFooter>
            {!recording ? (
              <Button
                className="w-full bg-education-700 hover:bg-education-800"
                onClick={handleStartRecording}
              >
                <Mic className="mr-2 h-4 w-4" />
                Start Recording
              </Button>
            ) : (
              <Button
                variant="destructive"
                className="w-full"
                onClick={handleStopRecording}
              >
                <MicOff className="mr-2 h-4 w-4" />
                Stop Recording
              </Button>
            )}
          </CardFooter>
        </Card>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Recorded Classes</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">28</div>
              <p className="text-xs text-muted-foreground">4 this week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Created Quizzes</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">15</div>
              <p className="text-xs text-muted-foreground">3 this week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Active Assignments</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">10</div>
              <p className="text-xs text-muted-foreground">Next due: Apr 15</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Classes */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Classes</CardTitle>
            <CardDescription>
              Review and manage your recorded classes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentClasses.map((classItem) => (
                <div
                  key={classItem.id}
                  className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="mb-3 md:mb-0">
                    <div className="flex items-center">
                      <h4 className="font-medium">{classItem.title}</h4>
                      {classItem.status === "Processing" && (
                        <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-full">
                          Processing
                        </span>
                      )}
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3 mr-1" />
                      {new Date(classItem.date).toLocaleDateString()}
                      <span className="mx-2">•</span>
                      <Clock className="h-3 w-3 mr-1" />
                      {classItem.duration}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className={classItem.notes ? "text-xs" : "text-xs opacity-50"}
                      disabled={!classItem.notes}
                    >
                      Notes
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className={classItem.flashcards ? "text-xs" : "text-xs opacity-50"}
                      disabled={!classItem.flashcards}
                    >
                      Flashcards
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className={classItem.quizzes ? "text-xs" : "text-xs opacity-50"}
                      disabled={!classItem.quizzes}
                    >
                      Quizzes
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      className="text-xs"
                    >
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              View All Classes
            </Button>
          </CardFooter>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Create New Assignment</CardTitle>
              <CardDescription>
                Assign new tasks to your students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full">Create Assignment</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Create Manual Quiz</CardTitle>
              <CardDescription>
                Build a custom quiz for your students
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full">Create Quiz</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default StaffDashboard;